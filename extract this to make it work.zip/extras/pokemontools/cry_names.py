# coding: utf-8

cry_names = ['%.2X' % x for x in xrange(0x44)]

