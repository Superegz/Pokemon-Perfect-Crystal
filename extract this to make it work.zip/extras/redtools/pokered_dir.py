import os

# TODO: use actual configuration
# Assume that the main pokered project dir is the current working directory
# (cwd).
pokered_dir = os.getcwd()
